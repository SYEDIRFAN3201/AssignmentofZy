import * as React from "react";
import { Logo } from "./Logo";
import { NavItem } from "./NavItem";
import { UserProfile } from "./UserProfile";

export default function Header() {
  const navItems = [
    { label: "Home", href: "/" },
    { label: "Products", href: "/products", hasDropdown: true },
    { label: "Resources", href: "/resources", hasDropdown: true },
    { label: "Pricing", href: "/pricing" },
  ];

  return (
    <header className="flex justify-center items-start w-full bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 min-w-[240px] w-[1280px] max-md:px-5">
        <nav className="flex flex-wrap gap-10 justify-between items-center self-stretch my-auto min-w-[240px] max-md:max-w-full">
          <Logo />
          <div className="flex gap-8 items-center self-stretch my-auto text-base font-semibold whitespace-nowrap min-w-[240px] text-slate-600">
            {navItems.map((item, index) => (
              <NavItem key={index} {...item} />
            ))}
          </div>
          <UserProfile />
        </nav>
      </div>
    </header>
  );
}
