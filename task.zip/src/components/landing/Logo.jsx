import * as React from "react";

export function Logo() {
  return (
    <div className="flex items-start self-stretch my-auto w-[142px]">
      <img
        loading="lazy"
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/87895e7ab93f9bf51ebd730a547fe20a4cc6d0395461710a543360f418208269?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
        alt="Company Logo"
        className="object-contain aspect-[4.44] w-[142px]"
      />
    </div>
  );
}
