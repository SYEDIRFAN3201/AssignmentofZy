export const featureCards = [
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/5f605a7ae5d5da9d971bd28fc9e0b535abf4b574bdfe55c77684799c3d0043bc?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
      title: "Share team inboxes",
      description: "Whether you have a team of 2 or 200, our shared team inboxes keep everyone on the same page and in the loop.",
      learnMoreIcon: "https://cdn.builder.io/api/v1/image/assets/TEMP/2dd85dfd5812d93e1d4a65ea72f001093c37c3443733700ae717c45f40073dad?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/a848c8e7be5d3b10353cccda1dbbf7dda50e299a03bd2dcb5ceee0f74ff621b9?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
      title: "Deliver instant answers",
      description: "An all-in-one customer service platform that helps you balance everything your customers need to be happy.",
      learnMoreIcon: "https://cdn.builder.io/api/v1/image/assets/TEMP/93a0bfcfb836381b74614377d5d1a293f1ace697fed38b4fb5cbea440855f395?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/5991d243cccf0e9d93d0da58791d932a8ecd818d36152852a33add935fdca35d?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
      title: "Manage your team with reports",
      description: "Measure what matters with Untitled's easy-to-use reports. You can filter, export, and drilldown on the data in a couple clicks.",
      learnMoreIcon: "https://cdn.builder.io/api/v1/image/assets/TEMP/1a6daeaff0430393099e37cfbfe61532244f6a74daa5346adf61b9bde43819bf?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
    }
  ];