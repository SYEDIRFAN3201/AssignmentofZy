export const blogPosts = [
    {
      id: 1,
      category: "Design",
      title: "UX review presentations",
      description: "How do you create compelling presentations that wow your colleagues and impress your managers?",
      image: "https://cdn.builder.io/api/v1/image/assets/TEMP/fba61d9629fc93368efec2a30f94d59f9cf728cdf4a1192f038a032b77f6a17a?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
      author: {
        name: "Olivia Rhye",
        avatar: "https://cdn.builder.io/api/v1/image/assets/TEMP/4e89480fe87ce892b3a0a47ca0cc97e3821c047eee5386c82debf1f97b1f3d6f?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
        date: "20 Jan 2024"
      }
    },
    {
      id: 2,
      category: "Product",
      title: "Migrating to Linear 101",
      description: "Linear helps streamline software projects, sprints, tasks, and bug tracking. Here's how to get started.",
      image: "https://cdn.builder.io/api/v1/image/assets/TEMP/d6b9eb8786835649de74c09f67852e3942fa47b6a19c975e2c1b3dff9a5e6871?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
      author: {
        name: "Phoenix Baker",
        avatar: "https://cdn.builder.io/api/v1/image/assets/TEMP/6954ceaad2c755ab4d1a7ebe8647299f1c14124884ea8ad842505367da878e5c?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
        date: "19 Jan 2024"
      }
    },
    {
      id: 3,
      category: "Software Engineering",
      title: "Building your API stack",
      description: "The rise of RESTful APIs has been met by a rise in tools for creating, testing, and managing them.",
      image: "https://cdn.builder.io/api/v1/image/assets/TEMP/0964fa6f117b489280997bc4aa18c5a141dc91a57d901003a5eecc3715a788a0?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
      author: {
        name: "Lana Steiner",
        avatar: "https://cdn.builder.io/api/v1/image/assets/TEMP/2d5ebb3f53148759b962043346e4605564dbbc2605dc463909491f400f41c6e8?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
        date: "18 Jan 2024"
      }
    }
  ];