export const faqItems = [
    {
      question: "Is there a free trial available?",
      answer: "Yes, you can try us for free for 30 days. If you want, we'll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible."
    },
    {
      question: "Can I change my plan later?",
      answer: ""
    },
    {
      question: "What is your cancellation policy?",
      answer: ""
    },
    {
      question: "Can other info be added to an invoice?",
      answer: ""
    },
    {
      question: "How does billing work?",
      answer: ""
    },
    {
      question: "How do I change my account email?",
      answer: ""
    }
  ];