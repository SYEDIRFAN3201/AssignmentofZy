import * as React from "react";

export default function FeatureCard({ icon, title, description }) {
  return (
    <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
      <img
        loading="lazy"
        src={icon}
        alt=""
        className="object-contain self-center w-12 shadow-sm aspect-square"
      />
      <div className="flex flex-col mt-5 w-full">
        <div className="text-xl font-semibold text-gray-900">{title}</div>
        <div className="mt-2 text-base leading-6 text-slate-600">
          {description}
        </div>
      </div>
    </div>
  );
}