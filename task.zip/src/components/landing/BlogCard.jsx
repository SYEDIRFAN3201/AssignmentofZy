import * as React from "react";

export function BlogCard({ category, title, description, image, author }) {
  return (
    <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
      <img
        loading="lazy"
        src={image}
        alt={`Blog post about ${title}`}
        className="object-contain w-full aspect-[1.6]"
      />
      <div className="flex flex-col mt-6 w-full">
        <div className="flex flex-col w-full">
          <div className="text-sm font-semibold leading-none text-violet-700">
            {category}
          </div>
          <div className="flex flex-col mt-2 w-full">
            <div className="flex gap-4 items-start w-full">
              <div className="flex-1 shrink text-2xl font-semibold leading-none text-gray-900 basis-0">
                {title}
              </div>
              <div className="flex flex-col pt-1 w-6">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/d69f07ce58248e9832734d04d647a7484264b318a6af5a3b919ef1588adcfdff?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
                  alt=""
                  className="object-contain w-6 aspect-square"
                />
              </div>
            </div>
            <div className="mt-2 text-base leading-6 text-slate-600">
              {description}
            </div>
          </div>
        </div>
        <div className="flex gap-3 items-center self-start mt-6">
          <div className="flex overflow-hidden relative flex-col justify-center self-stretch my-auto w-10 aspect-square min-h-[40px] rounded-[200px]">
            <img
              loading="lazy"
              src={author.avatar}
              alt={`${author.name}'s avatar`}
              className="object-cover absolute inset-0 size-full"
            />
            <div className="flex relative flex-1 w-full h-10 border-gray-900 border-solid border-[0.75px] min-h-[40px] opacity-[0.08] rounded-[200px]" />
          </div>
          <div className="flex flex-col self-stretch my-auto text-sm leading-none">
            <div className="font-semibold text-gray-900">{author.name}</div>
            <div className="text-slate-600">{author.date}</div>
          </div>
        </div>
      </div>
    </div>
  );
}