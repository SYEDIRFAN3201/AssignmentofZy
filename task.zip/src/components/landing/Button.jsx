import * as React from "react";

export function Button({ children, variant = "primary", ...props }) {
  const baseStyles = "overflow-hidden gap-2 self-stretch px-5 py-3 rounded-lg border border-solid shadow-sm font-semibold";
  const variants = {
    primary: "text-white bg-violet-500 border-violet-500",
    secondary: "bg-white text-slate-700 border-gray-300"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]}`}
      {...props}
    >
      {children}
    </button>
  );
}