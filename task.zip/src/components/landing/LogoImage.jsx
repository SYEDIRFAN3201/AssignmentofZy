import * as React from "react";

export function LogoImage({ src, width, aspectRatio, alt }) {
  return (
    <img
      loading="lazy"
      src={src}
      alt={alt}
      className={`object-contain shrink-0 self-stretch my-auto w-[${width}px]`}
      style={{ aspectRatio }}
    />
  );
}