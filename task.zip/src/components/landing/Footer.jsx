import * as React from "react";
import { FooterSection } from "./FooterSection";
import { Logo } from "./Logo";

export function Footer() {
  const footerSections = [
    {
      title: "Product",
      links: [
        { label: "Overview", href: "#" },
        { label: "Features", href: "#" },
        { label: "Solutions", href: "#", badge: "New" },
        { label: "Tutorials", href: "#" },
        { label: "Pricing", href: "#" },
        { label: "Releases", href: "#" },
      ],
    },
    {
      title: "Company",
      links: [
        "About us",
        "Careers",
        "Press",
        "News",
        "Media kit",
        "Contact",
      ].map((label) => ({
        label,
        href: "#",
      })),
    },
    {
      title: "Resources",
      links: [
        "Blog",
        "Newsletter",
        "Events",
        "Help centre",
        "Tutorials",
        "Support",
      ].map((label) => ({
        label,
        href: "#",
      })),
    },
    {
      title: "Use cases",
      links: [
        "Startups",
        "Enterprise",
        "Government",
        "SaaS centre",
        "Marketplaces",
        "Ecommerce",
      ].map((label) => ({
        label,
        href: "#",
      })),
    },
    {
      title: "Social",
      links: [
        "Twitter",
        "LinkedIn",
        "Facebook",
        "GitHub",
        "AngelList",
        "Dribbble",
      ].map((label) => ({
        label,
        href: "#",
      })),
    },
    {
      title: "Legal",
      links: [
        "Terms",
        "Privacy",
        "Cookies",
        "Licenses",
        "Settings",
        "Contact",
      ].map((label) => ({
        label,
        href: "#",
      })),
    },
  ];

  return (
    <footer className="flex flex-col items-center pt-16 pb-12 w-full bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full w-[1280px] max-md:px-5">
        <div className="flex flex-wrap gap-8 items-start w-full max-md:max-w-full">
          {footerSections.map((section, index) => (
            <FooterSection key={index} {...section} />
          ))}
        </div>
      </div>
      <div className="flex flex-col px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <div className="flex flex-wrap gap-10 justify-between items-center pt-8 w-full border-t border-solid border-t-gray-200 max-md:max-w-full">
          <Logo />
          <div className="self-stretch my-auto text-base text-gray-500 w-[293px]">
            © 2077 Untitled UI. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
