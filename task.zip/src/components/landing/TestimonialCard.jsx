import * as React from "react";

function TestimonialCard({ imageSrc, name, role }) {
  return (
    <div className="flex flex-col items-start w-full text-center max-md:max-w-full">
      <div className="flex overflow-hidden relative flex-col justify-center self-center w-16 aspect-square min-h-[64px] rounded-[200px]">
        <img
          loading="lazy"
          src={imageSrc}
          alt={`Profile picture of ${name}`}
          className="object-cover absolute inset-0 size-full"
        />
        <div className="flex relative flex-1 w-full h-16 border-gray-900 border-solid border-[0.75px] min-h-[64px] opacity-[0.08] rounded-[200px] " />
      </div>

      <div className="flex overflow-hidden relative flex-col justify-center self-center w-16 aspect-square min-h-[64px] rounded-[200px]">
      <div className="text-lg font-semibold leading-loose text-gray-900 max-md:max-w-full">
        {name}
      </div>
      <div className="mt-1 text-base text-slate-600 max-md:max-w-full">
        {role}
      </div>
      </div>
      
    </div>
  );
}

export default TestimonialCard;