import * as React from "react";
import { BlogCard } from "./BlogCard";
import { blogPosts } from "./data/BlogData";

export function BlogSection() {
  return (
    <div className="flex overflow-hidden flex-col items-center self-center py-24 w-full bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full w-[1280px] max-md:px-5">
        <div className="flex flex-wrap gap-10 justify-between items-start w-full max-md:max-w-full">
          <div className="flex flex-col min-w-[240px] w-[768px] max-md:max-w-full">
            <div className="flex flex-col w-full font-semibold max-md:max-w-full">
              <div className="text-base text-violet-700 max-md:max-w-full">
                Our blog
              </div>
              <div className="mt-3 text-4xl tracking-tighter leading-none text-gray-900 max-md:max-w-full">
                Lastest blog posts
              </div>
            </div>
            <div className="mt-5 text-xl text-slate-600 max-md:max-w-full">
              Tool and strategies modern teams need to help their companies grow.
            </div>
          </div>
          <button className="flex gap-3 items-start text-base font-semibold text-white overflow-hidden px-5 py-3 bg-violet-500 rounded-lg border border-violet-500 border-solid shadow-sm">
            View all posts
          </button>
        </div>
      </div>
      <div className="flex flex-col px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <div className="flex flex-wrap gap-8 items-start max-md:max-w-full">
          {blogPosts.map((post) => (
            <BlogCard key={post.id} {...post} />
          ))}
        </div>
      </div>
    </div>
  );
}