import * as React from "react";

export function FaqItem({ question, answer, isExpanded }) {
  return (
    <div className="flex flex-col w-full max-md:max-w-full">
      <div className="flex flex-wrap gap-6 items-start w-full max-md:max-w-full">
        <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px] max-md:max-w-full">
          <div className="text-lg font-medium leading-loose text-gray-900 max-md:max-w-full">
            {question}
          </div>
          {isExpanded && (
            <div className="mt-2 text-base leading-6 text-slate-600 max-md:max-w-full">
              {answer}
            </div>
          )}
        </div>
        <button 
          className="flex flex-col pt-0.5 w-6"
          aria-expanded={isExpanded}
          aria-label={isExpanded ? "Collapse answer" : "Expand answer"}
        >
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/034d558ecc8566c111eb1646350dd49f20b73630b56f70d2d0f76e8ea3137818?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
            alt=""
            className="object-contain w-6 aspect-square"
          />
        </button>
      </div>
    </div>
  );
}