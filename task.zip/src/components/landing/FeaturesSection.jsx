import * as React from "react";
import FeatureCard from "./FeatureCard";

const features = [
  {
    icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/6366ef52919c2f4368e8cd3280aa6744305c43e00c3c1bf371924e3a280f27e8?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
    title: "Share team inboxes",
    description: "Whether you have a team of 2 or 200, our shared team inboxes keep everyone on the same page and in the loop."
  },
  {
    icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/f0592b8ffc54fca55c167ea8cc6b18fd18d96f6735a28f89097492cf032f30cc?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
    title: "Deliver instant answers",
    description: "An all-in-one customer service platform that helps you balance everything your customers need to be happy."
  },
  {
    icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/5fadedd8158a7332dff74f74e7f49c44d25eb9a470ac3a4f5ed6a90182c0c173?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
    title: "Manage your team with reports",
    description: "Measure what matters with Untitled's easy-to-use reports. You can filter, export, and drilldown on the data in a couple clicks."
  },
  {
    icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/3d1df04e4a38142695bfd3e0f4b5d6be7f7cf02cf83c369e51a4f606b5b89f5f?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
    title: "Connect with customers",
    description: "Solve a problem or close a sale in real-time with chat. If no one is available, customers are seamlessly routed to email without confusion."
  },
  {
    icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/3d23ef28987d08c032e5f3292754676e2c5b40a537a5a1efa299892091b72922?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
    title: "Connect the tools you already use",
    description: "Explore 100+ integrations that make your day-to-day workflow more efficient and familiar. Plus, our extensive developer tools."
  },
  {
    icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/4b1e41c44ee00d6b6d2edbc5a204d4b773f53f3b220d22526f76cafee6e4e1d7?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de",
    title: "Our people make the difference",
    description: "We're an extension of your customer service team, and all of our resources are free. Chat to our friendly team 24/7 when you need help."
  }
];

export  function FeaturesSection() {
  return (
    <div className="flex overflow-hidden flex-col items-center py-24 w-full text-center bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full w-[1280px] max-md:px-5">
        <div className="flex flex-col items-center w-full max-md:max-w-full">
          <div className="flex flex-col max-w-full w-[768px]">
            <div className="flex flex-col items-start w-full font-semibold max-md:max-w-full">
              <p className="self-center mt-6 text-xl leading-8 text-center text-slate-600 w-[768px] max-md:max-w-full text-violet-700 ">
                Features
              </p>
              <div className="mt-3 text-4xl tracking-tighter leading-none text-gray-900 max-md:max-w-full">
                Analytics that feels like it's from the future
              </div>
            </div>
            <div className="mt-5 text-xl leading-8 text-slate-600 max-md:max-w-full">
              Powerful, self-serve product and growth analytics to help you
              convert, engage, and retain more users. Trusted by over 4,000
              startups.
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <div className="flex flex-wrap gap-8 items-start w-full max-md:max-w-full">
          {features.slice(0, 3).map((feature, index) => (
            <FeatureCard key={index} {...feature} />
          ))}
        </div>
        <div className="flex flex-wrap gap-8 items-start mt-16 w-full max-md:mt-10 max-md:max-w-full">
          {features.slice(3).map((feature, index) => (
            <FeatureCard key={index + 3} {...feature} />
          ))}
        </div>
      </div>
    </div>
  );
}