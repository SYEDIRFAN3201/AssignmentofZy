import * as React from "react";
import { LogoImage } from "./LogoImage";

const companyLogos = [
  { src: "https://cdn.builder.io/api/v1/image/assets/TEMP/04322aa649cba126b025e8b011ecbcfa41224659db030a84977eda791826d3df?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de", width: "170", aspectRatio: "3.55" },
  { src: "https://cdn.builder.io/api/v1/image/assets/TEMP/d59d9d147c5d7ecb730d7614f0ccb8966565990492ab60e9aeee69e05aeda816?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de", width: "167", aspectRatio: "3.48" },
  { src: "https://cdn.builder.io/api/v1/image/assets/TEMP/9e71058fa43fa15cd65b19ceb2340fd1381b6d68feb9ddf64f8ee1bc37f29835?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de", width: "198", aspectRatio: "4.13" },
  { src: "https://cdn.builder.io/api/v1/image/assets/TEMP/1117dd188bff9290f7cda131b9c85d4a962ff8e0711f32e7ddcac684e1488846?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de", width: "166", aspectRatio: "3.46" },
  { src: "https://cdn.builder.io/api/v1/image/assets/TEMP/2d4cc9c29b1be3f3fcc9487e8faea1216f1c8b4a326761b0b0fef7cf83c1fd5e?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de", width: "197", aspectRatio: "4.1" },
  { src: "https://cdn.builder.io/api/v1/image/assets/TEMP/54b052165be6046e0392bcec08127d612c454c253e0f133fa98d50f8583f95a5?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de", width: "182", aspectRatio: "3.79" }
];

export function CompanyLogos() {
  return (
    <div className="flex justify-center items-start py-24 w-full bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 min-w-[240px] w-[1280px] max-md:px-5">
        
          <p className="self-center mt-6 text-xl leading-8 text-center text-slate-600 w-[768px] max-md:max-w-full">Join 4,000+ companies already growing</p>
        
        <div className="flex flex-wrap gap-7 justify-between items-center mt-8 w-full max-md:max-w-full">
          {companyLogos.map((logo, index) => (
            <LogoImage
              key={index}
              src={logo.src}
              width={logo.width}
              aspectRatio={logo.aspectRatio}
              alt=""
            />
          ))}
        </div>
      </div>
    </div>
  );
}