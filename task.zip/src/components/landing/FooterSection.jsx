import * as React from "react";

export function FooterSection({ title, links }) {
  return (
    <div className="flex flex-col flex-1 shrink basis-0">
      <div className="text-sm font-semibold leading-none text-gray-500">
        {title}
      </div>
      <div className="flex flex-col items-start mt-4 w-full text-base text-slate-600">
        {links.map((link, index) => (
          <a
            key={index}
            href={link.href}
            className="flex gap-2 items-center mt-3 first:mt-0 hover:text-violet-700 transition-colors"
          >
            <span className="overflow-hidden gap-2 self-stretch my-auto">
              {link.label}
            </span>
            {link.badge && (
              <span className="px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-50 rounded-2xl border border-emerald-200 border-solid mix-blend-multiply">
                {link.badge}
              </span>
            )}
          </a>
        ))}
      </div>
    </div>
  );
}
