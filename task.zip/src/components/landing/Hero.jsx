import * as React from "react";

export function Hero() {
  return (
    <section className="flex overflow-hidden flex-col items-center pt-24 w-full max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full w-[1280px] max-md:px-5">
        <div className="flex flex-col items-center w-full max-md:max-w-full">
          <div className="flex flex-col max-w-full w-[1024px]">
            <div className="flex flex-col w-full max-md:max-w-full">
              <div className="flex gap-3 items-center self-center py-1 pr-2.5 pl-1 text-sm font-medium leading-none text-violet-700 bg-purple-50 rounded-2xl border border-purple-200 border-solid mix-blend-multiply">
                <div className="self-stretch px-2.5 py-0.5 my-auto text-center bg-white rounded-2xl border border-purple-300 border-solid">
                  New feature
                </div>
                <div className="flex gap-1 items-center self-stretch my-auto">
                  <div className="self-stretch my-auto">
                    Check out the team dashboard
                  </div>
                  <img
                    loading="lazy"
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/be6cdc3467111866934481e60618719b409be7d8142330760a119dd7e0e51d17?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
                    alt=""
                    className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                  />
                </div>
              </div>
              <h1 className="mt-4 text-6xl font-semibold tracking-tighter leading-tight text-center text-gray-900 max-md:max-w-full max-md:text-4xl">
                Beautiful analytics to grow smarter
              </h1>
            </div>
            <p className="self-center mt-6 text-xl leading-8 text-center text-slate-600 w-[768px] max-md:max-w-full">
              Powerful, self-serve product and growth analytics to help you
              convert, engage, and retain more users. Trusted by over 4,000
              startups.
            </p>
          </div>
          <div className="flex gap-3 items-start mt-12 text-lg font-semibold leading-loose max-md:mt-10">
            <button
              className="flex overflow-hidden gap-3 justify-center items-center px-7 py-4 whitespace-nowrap bg-white rounded-lg border border-gray-300 border-solid shadow-sm text-slate-700 max-md:px-5 hover:bg-gray-50 transition-colors"
              aria-label="Watch demo"
            >
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/784427ed17dff740476480dcb80dbf4802a2d80830154327e6ca7b66b4ecab7a?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
                alt=""
                className="object-contain shrink-0 self-stretch my-auto w-6 aspect-square"
              />
              <span>Demo</span>
            </button>
            <button
              className="overflow-hidden gap-3 self-stretch px-7 py-4 text-white bg-violet-500 rounded-lg border border-violet-500 border-solid shadow-sm max-md:px-5 hover:bg-violet-600 transition-colors"
              aria-label="Sign up"
            >
              Sign up
            </button>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-center px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/63b2531f4c52d3923f63a35a8250a761d980d312ae38ce134bd23add2791df54?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
          alt="Analytics Dashboard Preview"
          className="object-contain z-10 -mt-5 max-w-full rounded-xl border-4 border-gray-900 border-solid "
        />
      </div>
    </section>
  );
}
