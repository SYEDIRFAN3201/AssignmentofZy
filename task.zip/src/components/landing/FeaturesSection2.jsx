import * as React from "react";
import { FeatureCard2 } from "./FeatureCard2";
import { featureCards } from "./data/featurecards";

export function FeaturesSection2() {
  return (
    <div className="flex overflow-hidden flex-col items-center py-24 w-full bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full text-center w-[1280px] max-md:px-5">
        <div className="flex flex-col items-center w-full max-md:max-w-full">
          <div className="flex flex-col max-w-full w-[768px]">
            <div className="flex flex-col w-full max-md:max-w-full">
              <div className="self-center px-3 py-1 text-sm font-medium leading-none text-violet-700 whitespace-nowrap bg-purple-50 rounded-2xl border border-purple-200 border-solid mix-blend-multiply">
                Features
              </div>
              <h2 className="mt-4 text-4xl font-semibold tracking-tighter leading-none text-gray-900 max-md:max-w-full">
                Cutting-edge features for advanced analytics
              </h2>
            </div>
            <p className="mt-5 text-xl leading-8 text-slate-600 max-md:max-w-full">
              Powerful, self-serve product and growth analytics to help you
              convert, engage, and retain more users. Trusted by over 4,000
              startups.
            </p>
          </div>
        </div>
      </div>
      <div className="flex flex-col px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <div className="flex gap-8 items-start w-full h-[558px] max-md:max-w-full">
          <div className="flex flex-col flex-1 shrink items-center px-20 pb-32 w-full basis-0 min-w-[240px] max-md:px-5 max-md:pb-24 max-md:max-w-full">
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/18d40aefef71c835d657a0eb342342009dc4dd28b223066c877f08ff61e4dc12?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
              alt="Analytics dashboard preview"
              className="object-contain z-10 -mt-5 max-w-full rounded-xl border-4 border-gray-900 border-solid aspect-[1.48] w-[912px]"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-8 items-start mt-24 w-full max-md:mt-10 max-md:max-w-full">
          {featureCards.map((card, index) => (
            <FeatureCard2
              key={index}
              icon={card.icon}
              title={card.title}
              description={card.description}
              learnMoreIcon={card.learnMoreIcon}
            />
          ))}
        </div>
      </div>
    </div>
  );
}