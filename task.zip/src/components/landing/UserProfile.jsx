import * as React from "react";

export function UserProfile() {
  return (
    <div className="flex flex-col self-stretch my-auto w-10">
      <button
        className="flex overflow-hidden relative flex-col justify-center w-full aspect-square min-h-[40px] rounded-[200px] hover:opacity-90 transition-opacity"
        aria-label="User profile"
      >
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/ac65506cf39f36e26c59bcf5b65dee8af2b6f3f00190f64089a32f1fe7f32b55?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
          alt=""
          className="object-cover absolute inset-0 size-full"
        />
        <div className="flex relative flex-1 w-full h-10 border-gray-900 border-solid border-[0.75px] min-h-[40px] opacity-[0.08] rounded-[200px]" />
      </button>
    </div>
  );
}
