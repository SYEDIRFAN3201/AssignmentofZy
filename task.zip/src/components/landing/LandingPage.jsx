import * as React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import Header from "./Header";
import { Hero } from "./Hero";
import { FeaturesSection } from "./FeaturesSection";
import { FeaturesSection2 } from "./FeaturesSection2";
import { FaqSection } from "./FaqSection";
import { BlogSection } from "./BlogSection";
import {CallToAction} from "./CallToAction";
import { Footer } from "./Footer";
import { CompanyLogos } from "./CompanyLogos";
import TestimonialSection from "./TestimonialSection";

export default function LandingPage() {
  return (
    <Router>
      <div className="flex overflow-hidden flex-col bg-white">
        <Header />
        <main>
          <Hero />
          <CompanyLogos/>
          <FeaturesSection />
          <TestimonialSection/>
          <FeaturesSection2 />
          <FaqSection/>
          <BlogSection />
          <CallToAction/>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
