import * as React from "react";
import TestimonialCard from "./TestimonialCard";

function TestimonialSection() {
  return (
    <div className="flex overflow-hidden flex-col justify-center items-center py-24 w-full bg-gray-50 max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full w-[1280px] max-md:px-5">
        <div className="flex flex-col w-full max-md:max-w-full">
          <div className="flex flex-col w-full max-md:max-w-full">
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/74a86eebb46e9a07ef726d1ff03703b3c9593f5731c3946a7b12f0a93ce78152?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
              alt="Company logo"
              className="object-contain self-center max-w-full aspect-[3.5] w-[141px]"
            />
            <div className="mt-8 text-5xl font-medium tracking-tighter text-center text-gray-900 leading-[60px] max-md:max-w-full max-md:text-4xl max-md:leading-[56px]">
              We've been using Untitled to kick start every new project and
              can't imagine working without it.
            </div>
            <div className="flex flex-col mt-8 w-full max-md:max-w-full">
              <TestimonialCard
                imageSrc="https://cdn.builder.io/api/v1/image/assets/TEMP/70e658a23e3cece6400c59d4f0f0ebc90d4690b46d98a83cb5f40ac0fd5e99a5?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
                name="Candice Wu"
                role="Product Manager, Sisyphus"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TestimonialSection;