import * as React from "react";
import { faqItems } from "./data/FaqData";
import { FaqItem } from "./FaqItem";

export function FaqSection() {
  const [expandedIndex, setExpandedIndex] = React.useState(0);

  return (
    <div className="flex overflow-hidden flex-col items-center py-24 w-full bg-white max-md:max-w-full">
      <div className="flex flex-col px-8 max-w-full text-center w-[1280px] max-md:px-5">
        <div className="flex flex-col items-center w-full max-md:max-w-full">
          <div className="flex flex-col max-w-full w-[768px]">
            <h1 className="text-4xl font-semibold tracking-tighter leading-none text-gray-900 max-md:max-w-full">
              Frequently asked questions
            </h1>
            <p className="mt-5 text-xl text-slate-600 max-md:max-w-full">
              Everything you need to know about the product and billing.
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <div className="flex flex-col max-w-full w-[768px]">
          {faqItems.map((item, index) => (
            <div
              key={index}
              className={index !== 0 ? "flex flex-col pt-6 mt-8 w-full border-t border-solid border-t-gray-200 max-md:max-w-full" : ""}
            >
              <FaqItem
                question={item.question}
                answer={item.answer}
                isExpanded={index === expandedIndex}
              />
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col px-8 mt-16 max-w-full w-[1280px] max-md:px-5 max-md:mt-10">
        <div className="flex flex-col items-center p-8 w-full bg-gray-50 rounded-2xl max-md:px-5 max-md:max-w-full">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/bc5f57ffb42263413554058d7239b252961c8754fbd5a4bcefdc17250d281130?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
            alt=""
            className="object-contain max-w-full aspect-[2.14] w-[120px]"
          />
          <div className="flex flex-col mt-8 max-w-full text-center w-[768px]">
            <h2 className="text-xl font-semibold text-gray-900 max-md:max-w-full">
              Still have questions?
            </h2>
            <p className="self-center mt-2 text-lg leading-loose text-slate-600 max-md:max-w-full">
              Can't find the answer you're looking for? Please chat to our
              friendly team.
            </p>
          </div>
          <button 
            className="flex gap-3 items-start mt-8 text-base font-semibold text-white overflow-hidden px-5 py-3 bg-violet-500 rounded-lg border border-violet-500 border-solid shadow-sm"
            aria-label="Get in touch with our team"
          >
            Get in touch
          </button>
        </div>
      </div>
    </div>
  );
}