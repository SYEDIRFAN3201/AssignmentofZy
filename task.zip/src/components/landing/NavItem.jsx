import * as React from "react";
import { Link } from "react-router-dom";

export function NavItem({ label, href, hasDropdown }) {
  return (
    <div className="flex flex-col justify-center items-center self-stretch py-1 my-auto">
      <Link
        to={href}
        className="flex overflow-hidden gap-2 justify-center items-center hover:text-violet-700 transition-colors"
      >
        <span className="self-stretch my-auto">{label}</span>
        {hasDropdown && (
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/f6950ecb31c284909607359aa7e93f637fcc361cb6a8b3ca3a711b3f76044b1b?placeholderIfAbsent=true&apiKey=60dd854298264c4ea81d5e401fbca1de"
            alt=""
            className="object-contain shrink-0 self-stretch my-auto w-5 aspect-square"
          />
        )}
      </Link>
    </div>
  );
}
